(()=>{window.addEventListener("message",e=>{e.source===window&&e.data&&chrome.runtime.sendMessage(e.data)});function c(e){let o=Boolean(e.ng),t=document.querySelector("[ng-version]"),n=!1,s=!1;if(t){s=!0;let i=t.getAttribute("ng-version"),r=i?parseInt(i.split(".")[0],10):-1;i&&(r>=9||r===0)&&(n=!0)}e.postMessage({isIvy:typeof t?.__ngContext__<"u",isAngular:s,isDebugMode:o,isSupportedAngularVersion:n,isAngularDevTools:!0},"*"),s||setTimeout(()=>c(e),1e3)}function a(e){let o=`;(${e})(window)`,t=document.createElement("script");t.textContent=o,document.documentElement.appendChild(t);let n=t.parentElement;n&&n.removeChild(t)}document instanceof Document&&a(c.toString());})();
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
//# sourceMappingURL=ng_validate_bundle.js.map
